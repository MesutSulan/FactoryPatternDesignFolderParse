package com.folder.parse.saxfactory;

import com.folder.parse.saxdto.Staff;
import com.folder.parse.saxhandler.MapStaffObjectHandlerSax;
import org.xml.sax.SAXException;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.List;

public class SaxReader {

    public SaxReader getReader() {
        //InputStream is = new PipedInputStream();
        try {
            SAXParserFactory factory = SAXParserFactory.newInstance();

            FileInputStream fileInputStream = null;

            // parse XML and map to object, it works, but not recommend, try JAXB
            MapStaffObjectHandlerSax handler = new MapStaffObjectHandlerSax();

            SAXParser saxParser = null;
            fileInputStream = new FileInputStream("sax.xml");

            saxParser = factory.newSAXParser();

            saxParser.parse(fileInputStream, handler);

            // print all
            List<Staff> result = handler.getResult();
            result.forEach(System.out::println);

            // get List<Staff>
            new SaxWriterService().writeToXml(result);

        } catch (ParserConfigurationException | SAXException | IOException e) {
            e.printStackTrace();
        }
        return null;
    }
}
