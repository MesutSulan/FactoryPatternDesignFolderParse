package com.folder.parse.saxfactory;

import com.folder.parse.saxdto.Staff;

import javax.xml.stream.XMLOutputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamWriter;
import java.io.FileWriter;
import java.util.List;


public class SaxWriterService {
    XMLStreamWriter xsw = null;

    public SaxWriterService() {
        XMLOutputFactory xof = XMLOutputFactory.newInstance();

        try{
            xsw = xof.createXMLStreamWriter(new FileWriter("file.xml"));
        }
        catch (Exception e){
            System.err.println("Unable to write the file: " + e.getMessage());
        }
    }

    public void writeToXml(List<Staff> result)  {

        try {
            //xsw.writeStartDocument("UTF-8", "1.0");
            xsw.writeStartDocument();
            xsw.writeStartElement("company");

            for (Staff u : result) {
                xsw.writeStartElement("staff");
                xsw.writeAttribute("id", String.valueOf(u.getId()));
                createXmlLine("name",u.getName());
                createXmlLine("role",u.getRole());
                xsw.writeStartElement("salary");
                xsw.writeAttribute("currency",u.getCurrency());
                xsw.writeCharacters(String.valueOf(u.getSalary()));
                xsw.writeEndElement();
                createXmlLine("bio",u.getBio());
                xsw.writeEndElement();
            }
            xsw.writeEndElement();
            xsw.writeEndDocument();
            xsw.flush();
        } catch (Exception e) {
            System.err.println("Unable to write the file: " + e.getMessage());
        }
        finally {
            try {
                if (xsw != null) {
                    xsw.close();
                }
            } catch (Exception e) {
                System.err.println("Unable to close the file: " + e.getMessage());
            }

        }
    }

    private void createXmlLine(String name,String tageValue) throws XMLStreamException {
        xsw.writeStartElement(name);
        xsw.writeCharacters(tageValue);
        xsw.writeEndElement();

    }
}

