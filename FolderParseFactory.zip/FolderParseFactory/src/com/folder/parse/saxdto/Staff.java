package com.folder.parse.saxdto;

import lombok.*;

import java.math.BigDecimal;
@Data
public class Staff  {

    private Long id;
    private String name;
    private String role;
    private BigDecimal salary;
    private String currency;
    private String bio;
}
