package com.folder.parse.saxhandler;

import com.folder.parse.saxdto.Staff;
import org.xml.sax.Attributes;
import org.xml.sax.helpers.DefaultHandler;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

public class MapStaffObjectHandlerSax extends DefaultHandler {
    StringBuilder currentValue = new StringBuilder();
    List<Staff> result;
    Staff currentStaff;

    public List<Staff> getResult() {
        return result;
    }

    @Override
    public void startDocument() {
        result = new ArrayList<>();
    }

    @Override
    public void startElement(String uri, String localName, String qName, Attributes attributes) {
        currentValue.setLength(0);

        if (qName.equalsIgnoreCase("staff")) {

            currentStaff = new Staff();

            String id = attributes.getValue("id");
            currentStaff.setId(Long.valueOf(id));
        }
        if (qName.equalsIgnoreCase("salary")) {

            String currency = attributes.getValue("currency");
            currentStaff.setCurrency(currency);
        }
    }

    @Override
    public void endElement(String uri, String localName, String qName) {

        if (qName.equalsIgnoreCase("name")) {
            currentStaff.setName(new String(currentValue));
        }

        if (qName.equalsIgnoreCase("role")) {
            currentStaff.setRole(new String(currentValue));
        }

        if (qName.equalsIgnoreCase("salary")) {
            currentStaff.setSalary(new BigDecimal(currentValue.toString()));
        }

        if (qName.equalsIgnoreCase("bio")) {
            currentStaff.setBio(String.valueOf(currentValue));
        }

        if (qName.equalsIgnoreCase("staff")) {
            result.add(currentStaff);
        }
    }

    public void characters(char[] ch, int start, int length) {
        currentValue.append(ch, start, length);
    }
}

