package com.folder.parse.dto;

import com.folder.parse.interf.FolderParse;
import lombok.AllArgsConstructor;

import java.util.ArrayList;

@AllArgsConstructor
public class FileController implements FolderParse {
    private String line;
    private ArrayList<String> list;

    @Override
    public String line() {
        return this.line;
    }

    @Override
    public ArrayList<String> list() {
        return this.list;
    }
}
