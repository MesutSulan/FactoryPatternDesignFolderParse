package com.folder.parse.dto;

import com.folder.parse.interf.FolderParse;
import lombok.*;

import java.util.ArrayList;

@AllArgsConstructor
public class BufferedReader implements FolderParse {

    private String line;
    private ArrayList<String> list;

    @Override
    public String line() {
        return null;
    }

    @Override
    public ArrayList<String> list() {
        return null;
    }
}
