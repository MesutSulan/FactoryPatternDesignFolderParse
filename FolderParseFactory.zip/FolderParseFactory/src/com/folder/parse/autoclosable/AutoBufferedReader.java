package com.folder.parse.autoclosable;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.Reader;

public class AutoBufferedReader extends BufferedReader {

    public AutoBufferedReader(Reader in) {
        super(in);
    }

    @Override
    public void close() throws IOException {
        super.close();
        System.out.println("Closing CustomBufferedReader");
    }
}
