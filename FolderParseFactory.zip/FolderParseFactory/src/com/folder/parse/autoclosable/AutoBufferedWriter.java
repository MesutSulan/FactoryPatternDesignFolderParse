package com.folder.parse.autoclosable;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.Writer;

public class AutoBufferedWriter extends BufferedWriter {

    public AutoBufferedWriter(Writer out) {
        super(out);
    }

    @Override
    public void close() throws IOException {
        super.close();
        System.out.println("Closing CustomBufferedWriter");
    }
}
