package com.folder.parse.factory;

import com.folder.parse.autoclosable.AutoBufferedWriter;
import com.folder.parse.dto.FileController;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.util.ArrayList;

public class WriteFactory extends ReadWriteAbstract{
    @Override
    public BufferedWriter writeFolder(String line, File file) {

        try (FileWriter fileWritter = new FileWriter(file.getAbsolutePath(), true);
             BufferedWriter bufferWritter = new BufferedWriter(fileWritter);
             AutoBufferedWriter customBufferedWriter = new AutoBufferedWriter(bufferWritter)
        ) {
            customBufferedWriter.write(line);
            customBufferedWriter.newLine();

        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public BufferedReader reader() {
        return null;
    }

    @Override
    public FileController fileControl(String line, ArrayList<String> list) {
        return null;
    }

}
