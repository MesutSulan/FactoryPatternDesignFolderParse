package com.folder.parse.factory;

import com.folder.parse.dto.FileController;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

public abstract class ReadWriteAbstract {

    public abstract BufferedWriter writeFolder(String line, File file);
    public abstract BufferedReader reader() throws IOException;

    public abstract FileController fileControl(String line, ArrayList<String> list) throws IOException;

}
