package com.folder.parse.factory;

import com.folder.parse.dto.FileController;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import static com.folder.parse.factory.CreateNewFile.createNewFile;

public class FileFactory extends ReadWriteAbstract {
    public static final String USE_ISIS = "USE [isis]";
    private static ArrayList<String> list = null;
    private static String fileName = null;
    private static File file = null;
    private WriteFactory writeFile = new WriteFactory();

    @Override
    public BufferedWriter writeFolder(String line, File file) {
        return null;
    }

    @Override
    public BufferedReader reader() throws IOException {
        return null;
    }

    @Override
    public FileController fileControl(String line, ArrayList<String> list) throws IOException {

        List<String> subjectList = new ArrayList<>();
        for (int i = 0; i < list.size(); i++) {
            line = list.get(i);
            if (line.startsWith("GO")
                    || line.startsWith("/****** Object:")
                    || line.startsWith("SET ANSI_NULLS ON")
                    || line.startsWith("SET QUOTED_IDENTIFIER ON")) {
                subjectList.add(line);
                continue;

            }

            if (line.startsWith("CREATE PROCEDURE")
                    || line.startsWith("create procedure")) {

                fileName = findFileName(line);
                file = createNewFile(fileName);
                writeFile.writeFolder(USE_ISIS, file);
                for (String subject : subjectList) {
                    writeFile.writeFolder(subject, file);
                }
                subjectList.clear();

            }
            if (file != null) {
                writeFile.writeFolder(line, file);
            }
        }


        return null;
    }

    private static String findFileName(String findName) {
        findName = findName.substring(findName.indexOf("[dbo].[") + 7);
        findName = findName.substring(0, findName.indexOf("]"));
        return findName;
    }
}