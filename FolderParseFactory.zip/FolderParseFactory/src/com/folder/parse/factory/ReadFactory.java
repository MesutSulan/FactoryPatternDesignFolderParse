package com.folder.parse.factory;

import com.folder.parse.autoclosable.AutoBufferedReader;
import com.folder.parse.dto.FileController;

import java.io.*;
import java.util.ArrayList;

public class ReadFactory extends ReadWriteAbstract{

    static FileFactory fileController = new FileFactory();

    private String line;
    private ArrayList<String> list;

    public ReadFactory(String line, ArrayList<String> list) {
        this.line = line;
        this.list = list;
    }

    @Override
    public BufferedWriter writeFolder(String line, File file) {
        return null;
    }

    @Override
    public BufferedReader reader() throws IOException {

        try (FileReader fileReader = new FileReader("attis.sql");
             BufferedReader reader = new BufferedReader(fileReader);
             AutoBufferedReader customBufferedReader = new AutoBufferedReader(reader)
        ) {
                line = customBufferedReader.readLine();
            while (line != null) {
                //System.out.println(line);
                list.add(line);

                // read next line
                line = customBufferedReader.readLine();

            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        fileController.fileControl(line,list);
        return null;
    }

    @Override
    public FileController fileControl(String line, ArrayList<String> list) {
        return null;
    }

}
