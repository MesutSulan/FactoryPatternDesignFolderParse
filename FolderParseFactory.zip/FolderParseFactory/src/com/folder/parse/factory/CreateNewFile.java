package com.folder.parse.factory;

import java.io.File;
import java.io.IOException;

public class CreateNewFile {

    public static File createNewFile(String currentFileName) throws IOException {
        File file;
        try {
            // file path
            file = new File("C:\\Users\\LENOVO\\Desktop\\MyFolder\\" + currentFileName + ".sql");

            // Checks if the file exists
            // Create new file

            if (file.createNewFile()) {
                System.out.println("First File created");
                return file;
            } else {
                System.out.println("File already exists");
            }

        } catch (IOException e) {
            // if it does not exist
            // Create another File

            file = new File("C:\\Users\\LENOVO\\Desktop\\MyAnotherFolder\\" + currentFileName + ".sql");

            if (file.createNewFile()) {

                System.out.println("Second File created");
                return file;
            } else {

                System.out.println("File already exists");
            }
        }
        return null;
    }
}
