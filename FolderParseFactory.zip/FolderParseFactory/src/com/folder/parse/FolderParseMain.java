package com.folder.parse;

import com.folder.parse.factory.ReadFactory;

import java.io.IOException;
import java.util.ArrayList;

public class FolderParseMain {
    public static void main(String[] args) throws IOException {

        ReadFactory readFactory = new ReadFactory("",new ArrayList<>());
        readFactory.reader();
    }
}
