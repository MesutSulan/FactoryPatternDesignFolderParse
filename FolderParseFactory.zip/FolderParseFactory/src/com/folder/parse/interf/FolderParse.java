package com.folder.parse.interf;

import java.util.ArrayList;

public interface FolderParse {
    String line();
    ArrayList<String> list();

}
