package com.folder.parse;

import com.folder.parse.saxfactory.SaxReader;

public class XMLSaxParseMain {
    public static void main(String[] args) {

        SaxReader saxReader = new SaxReader();
        saxReader.getReader();
    }
}
